$ unzip fairseq-a54021305d6b3c4c5959ac9395135f63202db8f1.zip
$ cd fairseq-a54021305d6b3c4c5959ac9395135f63202db8f1
$ pip install --editable ./
$ cd ..
